/**
 * @Sujata Avirneni
 *
 */
package Pardot.Pardot_ToolBox.Pardot_Pages;

//import com.nextgen.qa.automation.toolbox.Artifact;
import Pardot.Pardot_ToolBox.AutomationSettings;
import Pardot.Pardot_ToolBox.GeneralMethods;
import Pardot.Pardot_ToolBox.MouseMethods;
import UI.GenericPage;
import Pardot.Pardot_ToolBox.Pardot_Pages.MainPage;
import java.io.IOException;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MainPage extends GenericPage {

	/**
	 * 
	 */
	public MainPage(WebDriver aDriver, String aLOG_FILE) {	
		   super(aDriver, aLOG_FILE);
		   this.driver = aDriver;
	       this.LOG_FILE = aLOG_FILE;
		}

	public int EVENT_DELAY = AutomationSettings.getEventDelay();
	
	// Web Elements   
    
    @FindBy(how = How.CSS, using = "span[id='loggedInUser'][class^='navLink']")
    public WebElement loggedUserStatus;
    
    @FindBy(how = How.CSS, using = "div[id='loggedInUserDropdown'][class^='navDropDown'] li")
    public List<WebElement> loggedUserStatusDropdownList;
    
    @FindBy(how = How.CSS, using = "div[class^='systemStatus']")
    public WebElement statusIcon;
    
    //@FindBy(how = How.CSS, using = "span[class='location-user-status'] div[class^='tooltip']")
    @FindBy(how = How.CSS, using = "body span[class ^= 'ngx-tooltip']") // MGB 10/17/2014
    public WebElement statusIconToolTip;
      
    public String globalSearchFieldCss = "input[id ='globalSearchBox']";
    
    @FindBy(how = How.CSS, using = "div[class^='detailText']")
    public WebElement resultDetail;
    public WebElement primaryActionButton = null;
    public String primaryActionButtonCss = "ul[class^='primary-action-button']";
    public WebElement arrowDown = null;
    public String arrowDownCss = "div[class^='arrow-down']";
       
    
    @FindBy(how = How.CSS, using = "li[class='logout']")
    public WebElement logoutOption; 
    
    @FindBy(how = How.CSS, using = "div[class^='navbar-tab patient'] span[class='navbar-tab-close']")
    public List<WebElement> tabCloseButtons;
    
    @FindBy(how = How.CSS, using = "span[id='loggedInUser'][class^='navLink']") //MGB 7/2/2014
    public WebElement userStatus;
    
    //@FindBy(how = How.CSS, using = "div[id='userStatusDropDown'][class^='navDropDown'] li")
    @FindBy(how = How.CSS, using = "div[id*='UserDropDown'][class^='navDropDown'] li") // MGB 10/17/2014
    public List<WebElement> userStatusList;
    
    @FindBy(how = How.CSS, using = "div[class='copyright-info']")
    public WebElement copyrightInfo;
     
    //layout
    @FindBy(how = How.CSS, using = "div[class^='ngxSelect'][sel-url-value-field='LayoutId'] a[class*='customSelect']")
    public WebElement layoutSelectField;
    
    @FindBy(how = How.CSS, using = "div[class^='ngxSelect'][sel-url-value-field='LayoutId'] li")
    public List<WebElement> layoutSelectList;  
    
    @FindBy(how = How.CSS, using = "div[class^='lockScreenBg']")
    public WebElement userLoginLockPopup;
    
    
    //actions
      
    
    public boolean clickUserStatus () throws IOException, InterruptedException {
    	return super.clickElement(userStatus, "User Status button");
    }
    
    public boolean clickLoggedUserStatus () throws IOException, InterruptedException {
    	return super.clickElement(loggedUserStatus, "User Status button");
    }
    
   
    public boolean selectLayout(String layoutName) throws IOException, InterruptedException {
        return super.selectDropdownItem(layoutSelectList, "Layout Select List", layoutName);
    }
      
    
    public boolean logOutUser() throws IOException, InterruptedException {
    	super.clickElement(loggedUserStatus, "Logged User Status button");
    	GeneralMethods.delay(AutomationSettings.getEventDelay());
    	return super.clickElement(logoutOption, "Log out option");
    }
        
    
    public String getBuildNumber() throws InterruptedException {
    	try{
    		String info = this.displayStatusTooltip();
    		String [] infoArry = info.split("Version");
    		infoArry[1] = infoArry[1].replace(" - ", "");
    		return infoArry[1]; 
    	} catch (Exception e) { 
    		return ""; 
    	}
    }
    
    public String getElapsedTime() throws InterruptedException {
    	try{
    		String info = this.displayStatusTooltip();
    		String [] infoArry = info.split("Version");
    		infoArry[0] = infoArry[0].replace("Status: Connected | Duration: ", "");
    		return infoArry[0]; 
    	} catch (Exception e) { 
    		return ""; 
    	}
    }
    
    public String displayStatusTooltip() throws InterruptedException {
    	try{
    		String info = "";
    		boolean success = true;
    		if (MouseMethods.HoverOver(this.driver, this.statusIcon, 1, 1))
    			if (! this.statusIconToolTip.isDisplayed()) success = false;
    			else 
    				info = this.statusIconToolTip.getText();
    		//info = StringUtils.chomp(info); // MGB 10/27/2014
    		info = info.replace("\n", ""); // MGB 10/27/2014
    		return info; 
    	} catch (Exception e) { return ""; }
    }
    
    public String checkLoginSucceeded() throws Exception {
    	String success = "00";
    	
    	//if (! GeneralMethods.checkIsDisplayed(this.homeMenu)) 
    		success += "01";
    	
    	this.checkErrorPage();
    		
    	return success;
    }
    	
	public boolean verifyTitleLayout(WebElement element1,WebElement element2, String string1, String string2) throws IOException {
		boolean success = true;
		try {
		String ImageValue = super.getText(element1, "Welcome Image");
		String ImageValue1 = super.getText(element2, "Welcome Image2");
		if (ImageValue.equalsIgnoreCase(string1) && ImageValue1.equalsIgnoreCase(string2))
		{
		success = true ;	
		}
		else 
		{
			success = false;
		}
		System.out.println(" the boolean"+success);
		return success;
		}
		catch (Exception e) { return false;}
	}
    // end of Layout Changes
	
	
		
	
	
	

	


}
