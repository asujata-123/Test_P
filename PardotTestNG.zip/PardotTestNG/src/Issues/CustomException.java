package Issues;

public class CustomException extends Exception
{
	public String toString() {
	   return "Exception occurred 504 Occurred";
        }
	
}

